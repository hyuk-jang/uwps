const serialport = require('serialport');
const SerialConnector = require('./SerialConnector.js');

class SerialDataHandler extends SerialConnector {
  constructor(deivceInfo = {
    port,
    baudRate,
    transportCode,
    identificationCode,
  }, connIntervalSec) {
    super(deivceInfo, connIntervalSec);

  }

  // 초기에 데이터를 입력해야할 경우에
  init() {
    console.log("핸들러 init")
  }

  // 데이터 처리 핸들러
  processData(resData) {
    console.log("핸들러 processData",resData)
  }



}

module.exports = SerialDataHandler;