
const control = require("./control.js");
const presentation = require("./presentation.js");

module.exports = () => {
  return {
    control,
    presentation
  }
}

