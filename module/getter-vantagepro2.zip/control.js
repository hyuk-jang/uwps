const EventEmitter = require('events');


class SerialController extends EventEmitter {
  constructor() {
    super();
  }
}

module.exports = (parents) => {
  const serialController = new SerialController();

  serialController.on('searchMatchingDevice', (deviceInfoList, callback) => {
    const SerialChecker = require('./SerialChecker.js');
    const serialChecker = new SerialChecker(deviceInfoList);
    serialChecker.doChecker((possibleSerialDevice) => {
      return possibleSerialDevice;
    });
  });

  serialController.on('connSerial', (serialInfo) => {
    const presentaion = require('./presentation.js');
    if (serialInfo.deviceName == 'vantagePro2') {

      console.log('밴티지 프로 2')
    } else if (serialInfo.deviceName == 'infraredRainSensor') {
      let infraredRainSensor = new presentaion.InfraredRainSensor(serialController, serialInfo);
      infraredRainSensor.connect();
      console.log('infraredRainSensor')
    }
  });


  serialController.on('resRainValue', averRain => {
    console.log('resRainValue', averRain)
  });



  return serialController;
}