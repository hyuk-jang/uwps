
// module.exports = () => {
//   return require("./control.js")();
// } 


module.exports = require("./control.js");