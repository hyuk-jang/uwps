var SerialConnector = require('./SerialConnector.js');
exports.InfraredRainSensor = class extends SerialConnector {
  constructor(parents, deivceInfo = {
    port,
    baudRate,
    transportCode,
    identificationCode,
  }, connIntervalSec) {
    super(deivceInfo, connIntervalSec);

    // control 객체
    this.parents = parents;
    // 비의 영역
    this.fineRainBoundary = 300;
    this.heavyRainBoundary = 500;
    this.arrRainStorage = [];
    // 데이터 추출하기 위한 변수
    this.bufferMaxSize = 70;
    this.rainDataSize = 8;
    this.totalBuffer = new Buffer(this.bufferMaxSize);
    this.rainSeparator = 'RAIN %=';

  }

  // 초기에 데이터를 입력해야할 경우에
  init() {
    console.log('핸들러 init')
  }

  // 데이터 처리 핸들러
  processData(resData) {
    // console.log('### Receive: ', resData.toString())

    let strData = resData.toString();

    // 무조건 Buffer Add
    this.totalBuffer += Buffer.from(resData)

    // 입력된 Buffer를 String 변환
    let strBuffer = this.totalBuffer.toString();

    // Trans Key는 VIS로 자체 판단(프로토콜 정의 문서가 없음)
    if (strBuffer.indexOf('VIS') != -1) {
      // strBuffer에 rainSeparator가 포함되어 있다면 판독 시작
      let rainSeparatorIndex = strBuffer.indexOf(this.rainSeparator);
      if (rainSeparatorIndex != -1) {
        // 의미있는 RainData 길이는 총 8btye
        let substrRainData = strBuffer.substr(rainSeparatorIndex + this.rainSeparator.length, this.rainDataSize);

        // 의미있는 값인지 체크. Buffer 생성시 Garbage 데이터가 들어가므로
        let pattern = /[^{0-9}{A-F}]/;
        let hasAvailData = pattern.test(substrRainData);
        // 데이터가 맞다면 16진수를 10진수로 변환하고 Buffer를 비움
        if (!hasAvailData) {
          let rainData = this.converter().hex2dec(substrRainData);
          // console.log('rainData',rainData)
          //console.log('rainData', rainData)
          this.logicRain(rainData);
          this.totalBuffer = new Buffer(this.bufferMaxSize);
        }
      }
    }
  }

  logicRain(rainData) {
    //console.log('RainData', rainData)
    const boundaryCount = 3;
    let totalData = 0;
    let averRain = 0;
    this.arrRainStorage = this._getArrBoundary(this.arrRainStorage, rainData, boundaryCount);

    // console.log('this.arrRainStorage',this.arrRainStorage)
    if (this.arrRainStorage.length < boundaryCount) {
      // console.log('평균값 아직 안됨.')
      return;
    }



    this.arrRainStorage.forEach((rData, index) => {
      totalData += Number(rData);
    })
    averRain = parseInt(totalData / this.arrRainStorage.length);

    // console.log('averRain', averRain)
    this.parents.emit('resRainValue', averRain)
  }

  _getArrBoundary(prevArr, newData, arrLength) {
    var returnvalue = [];

    if(isNaN(newData)){
      console.log('new RainData is NaN');
      return returnvalue;
    }

    // console.log('newData',newData)
    newData = Array.isArray(newData) ? newData : [newData];
    arrLength = arrLength == null || arrLength == '' ? 1 : arrLength;

    returnvalue = prevArr.concat(newData);

    if (returnvalue.length > arrLength) {
      var spliceIndex = returnvalue.length - arrLength;
      returnvalue.splice(0, spliceIndex);
    }
    return returnvalue;
  }
}